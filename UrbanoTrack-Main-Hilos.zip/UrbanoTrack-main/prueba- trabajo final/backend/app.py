from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import bcrypt
import db
from datetime import datetime
import threading
import time
import requests

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

OTRO_SERVIDOR = "http://localhost:5000"



def sincronizar_con_otro_servidor():
    while True:
        try:
            r = requests.get(f"{OTRO_SERVIDOR}/api/vehiculos", timeout=3)
            if r.status_code == 200:
                print(" Vehículos sincronizados:", len(r.json()))
            else:
                print(" Error consultando servidor remoto")
        except Exception as e:
            print(" No se pudo sincronizar:", e)
        time.sleep(10)


def monitorear_vehiculos():
    while True:
        try:
            con = db.get_connection()
            cur = con.cursor(dictionary=True)
            cur.execute("SELECT id, estado FROM vehiculos")
            datos = cur.fetchall()
            cur.close()
            con.close()
            print("[MONITOR] Vehículos revisados:", len(datos))
        except Exception as e:
            print("[MONITOR] Error:", e)
        time.sleep(5)


def iniciar_hilos():
    threading.Thread(target=sincronizar_con_otro_servidor).start()
    threading.Thread(target=monitorear_vehiculos).start()



@app.route('/')
def index():
    return render_template("index.html")

@app.route('/login')
def login_page():
    return render_template("login.html")

@app.route('/register')
def register_page():
    return render_template("register.html")

@app.route('/panel_usuario')
def panel_usuario():
    return render_template("panel_usuario.html")

@app.route('/panel_admin')
def panel_admin():
    return render_template("panel_admin.html")

@app.route('/panel_conductor')
def panel_conductor():
    return render_template("panel_conductor.html")


@app.before_request
def mostrar_ip():
    print("Conexión desde:", request.remote_addr)



def registrar_bitacora(usuario, accion, resultado="Éxito"):
    try:
        con = db.get_connection()
        cur = con.cursor()
        fecha = datetime.now().strftime("%Y-%m-%d")
        cur.execute(
            "INSERT INTO bitacora (usuario, fecha, accion, resultado) VALUES (%s,%s,%s,%s)",
            (usuario, fecha, accion, resultado)
        )
        con.commit()
    except Exception as e:
        print("Error guardando bitácora:", e)
    finally:
        cur.close()
        con.close()


@app.route("/api/bitacora", methods=["GET", "POST", "DELETE"])
def api_bitacora():
    if request.method == "GET":
        con = db.get_connection()
        cur = con.cursor(dictionary=True)
        cur.execute("SELECT * FROM bitacora ORDER BY id DESC")
        data = cur.fetchall()
        cur.close()
        con.close()
        return jsonify(data)

    if request.method == "POST":
        data = request.json
        registrar_bitacora(data["usuario"], data["accion"], data.get("resultado", "Éxito"))
        return jsonify({"mensaje": "Registro guardado"}), 201

    if request.method == "DELETE":
        con = db.get_connection()
        cur = con.cursor()
        cur.execute("DELETE FROM bitacora")
        con.commit()
        cur.close()
        con.close()
        return jsonify({"mensaje": "Bitácora eliminada"})



@app.route("/api/register", methods=["POST"])
def register():
    data = request.json
    nombre = data.get("nombre_usuario")
    correo = data.get("correo")
    contra = data.get("contrasena")
    rol = data.get("rol")

    hashed = bcrypt.hashpw(contra.encode(), bcrypt.gensalt()).decode()

    con = db.get_connection()
    cur = con.cursor()
    cur.execute(
        "INSERT INTO usuarios (nombre_usuario, correo, contrasena, rol) VALUES (%s,%s,%s,%s)",
        (nombre, correo, hashed, rol)
    )
    con.commit()
    cur.close()
    con.close()

    return jsonify({"mensaje": "Usuario registrado"}), 201


@app.route("/api/login", methods=["POST"])
def login():
    data = request.json
    con = db.get_connection()
    cur = con.cursor(dictionary=True)
    cur.execute("SELECT * FROM usuarios WHERE correo=%s", (data["correo"],))
    user = cur.fetchone()
    cur.close()
    con.close()

    if not user:
        return jsonify({"error": "Credenciales incorrectas"}), 401

    if user["estado"] == "bloqueado":
        return jsonify({"error": "Cuenta bloqueada"}), 403

    if not bcrypt.checkpw(data["contrasena"].encode(), user["contrasena"].encode()):
        return jsonify({"error": "Credenciales incorrectas"}), 401

    return jsonify({"mensaje": "OK", "usuario": user})



@app.route("/api/usuarios", methods=["GET"])
def api_usuarios():
    con = db.get_connection()
    cur = con.cursor(dictionary=True)
    cur.execute("SELECT id, nombre_usuario AS username, rol, estado FROM usuarios")
    data = cur.fetchall()
    cur.close()
    con.close()
    return jsonify(data)



@app.route("/api/usuarios/<int:id>/estado", methods=["PUT"])
def actualizar_estado_usuario(id):
    data = request.json
    nuevo_estado = data.get("estado")

    if nuevo_estado not in ["activo", "bloqueado"]:
        return jsonify({"error": "Estado inválido"}), 400

    con = db.get_connection()
    cur = con.cursor()
    cur.execute("UPDATE usuarios SET estado=%s WHERE id=%s", (nuevo_estado, id))
    con.commit()
    cur.close()
    con.close()

    return jsonify({"mensaje": "Estado actualizado", "estado": nuevo_estado})



@app.route("/api/usuarios/<int:id>/rol", methods=["PUT"])
def actualizar_rol_usuario(id):
    data = request.json
    nuevo_rol = data.get("rol")

    if not nuevo_rol:
        return jsonify({"error": "Falta el campo 'rol'"}), 400

    con = db.get_connection()
    cur = con.cursor()

    try:
        cur.execute("UPDATE usuarios SET rol=%s WHERE id=%s", (nuevo_rol, id))
        con.commit()

        if cur.rowcount == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        return jsonify({"mensaje": "Rol actualizado correctamente", "rol": nuevo_rol})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        cur.close()
        con.close()


@app.route("/api/usuarios/<int:id>", methods=["DELETE"])
def eliminar_usuario(id):
    con = db.get_connection()
    cur = con.cursor()
    cur.execute("DELETE FROM usuarios WHERE id=%s", (id,))
    con.commit()
    cur.close()
    con.close()
    return jsonify({"mensaje": "Usuario eliminado"})



@app.route("/api/vehiculos", methods=["GET", "POST"])
def api_vehiculos():
    con = db.get_connection()
    cur = con.cursor(dictionary=True)

    if request.method == "GET":
        cur.execute("SELECT * FROM vehiculos")
        data = cur.fetchall()
        cur.close()
        con.close()
        return jsonify(data)

    if request.method == "POST":
        d = request.json
        cur.execute(
            "INSERT INTO vehiculos (tipo, patente, numero_ruta, conductor) VALUES (%s,%s,%s,%s)",
            (d["tipo"], d["patente"], d["ruta"], d["conductor"])
        )
        con.commit()
        cur.close()
        con.close()
        return jsonify({"mensaje": "Vehículo creado"}), 201


@app.route("/api/vehiculos/<int:id>", methods=["DELETE"])
def api_vehiculo_delete(id):
    con = db.get_connection()
    cur = con.cursor()
    cur.execute("DELETE FROM vehiculos WHERE id=%s", (id,))
    con.commit()
    cur.close()
    con.close()
    return jsonify({"mensaje": "Vehículo eliminado"})



@app.route("/api/rutas", methods=["GET", "POST"])
def api_rutas():
    con = db.get_connection()
    cur = con.cursor(dictionary=True)

    if request.method == "GET":
        cur.execute("SELECT * FROM rutas")
        data = cur.fetchall()
        cur.close()
        con.close()
        return jsonify(data)

    if request.method == "POST":
        d = request.json
        cur.execute(
            "INSERT INTO rutas (nombre_ruta, origen) VALUES (%s,%s)",
            (d["nombre"], d["origen"])
        )
        con.commit()
        cur.close()
        con.close()
        return jsonify({"mensaje": "Ruta creada"}), 201


@app.route("/api/rutas/<int:id>", methods=["DELETE"])
def api_ruta_delete(id):
    con = db.get_connection()
    cur = con.cursor()
    cur.execute("DELETE FROM rutas WHERE id=%s", (id,))
    con.commit()
    cur.close()
    con.close()
    return jsonify({"mensaje": "Ruta eliminada"})



if __name__ == "__main__":
    iniciar_hilos()
    app.run(host="0.0.0.0", port=5000, debug=True)
