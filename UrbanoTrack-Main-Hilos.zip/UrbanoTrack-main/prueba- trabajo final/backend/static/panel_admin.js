

let usuarioActual = localStorage.getItem("usuarioLogueado") || null;
let bitacora = [];
let rutas = [];
let vehiculos = [];
let usuarios = [];
let conductores = [];

const sidebarLinks = document.querySelectorAll(".sidebar a");
const sections = document.querySelectorAll(".panel-section");




document.addEventListener("click", (e) => {
    if (["SELECT", "BUTTON", "INPUT", "OPTION"].includes(e.target.tagName)) {
        e.stopPropagation(); 
    }
});




async function inicializarUsuario() {
    if (!usuarioActual) {
        try {
            const res = await fetch("/api/usuarios");
            const users = await res.json();
            const username = users.length > 0 ? users[0].username : "admin";
            usuarioActual = { username };
            localStorage.setItem("usuarioLogueado", JSON.stringify(usuarioActual));
        } catch (e) {
            console.error("Error cargando usuarios:", e);
            usuarioActual = { username: "admin" };
            localStorage.setItem("usuarioLogueado", JSON.stringify(usuarioActual));
        }
    } else {
        if (typeof usuarioActual === "string") {
            usuarioActual = JSON.parse(usuarioActual);
        }
    }

    inicializar();
}


sidebarLinks.forEach(link => {
    link.addEventListener("click", () => {
        sidebarLinks.forEach(l => l.classList.remove("active"));
        link.classList.add("active");
        sections.forEach(sec => sec.classList.remove("active"));
        document.getElementById(link.dataset.section).classList.add("active");
    });
});



async function inicializar() {
    await cargarRutasDB();
    await cargarVehiculosDB();
    await cargarSeguridad();
    await cargarBitacoraDB();
    await cargarSelectConductores();
}

inicializarUsuario();




async function registrarBitacora(accion, resultado = "Éxito") {
    if (!usuarioActual || !usuarioActual.username) {
        usuarioActual = { username: "admin" };
    }

    const log = {
        usuario: usuarioActual.username,
        fecha: new Date().toISOString(),
        accion,
        resultado
    };

    try {
        await fetch("/api/bitacora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(log)
        });
        await cargarBitacoraDB();
    } catch (e) {
        console.error("Error registrando bitácora:", e);
    }
}

document.getElementById("btnResetBitacora").addEventListener("click", async () => {
    if (!confirm("¿Seguro que quieres limpiar toda la bitácora? Esta acción no se puede deshacer.")) return;

    try {

        const resDelete = await fetch("/api/bitacora", { method: "DELETE" });
        if (!resDelete.ok) throw new Error("Error limpiando bitácora");

        const log = {
            usuario: usuarioActual?.username || "admin",
            fecha: new Date().toISOString(),
            accion: "Limpieza de bitácora realizada",
            resultado: "Éxito"
        };

        const resPost = await fetch("/api/bitacora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(log)
        });
        if (!resPost.ok) throw new Error("Error registrando limpieza en bitácora");

  
        await cargarBitacoraDB();
        alert("Bitácora limpiada y registro agregado correctamente.");
    } catch (e) {
        console.error(e);
        alert("No se pudo limpiar la bitácora.");
    }
});



async function cargarBitacoraDB() {
    try {
        const res = await fetch("/api/bitacora");
        bitacora = await res.json();
        cargarBitacora(bitacora);
    } catch (e) {
        console.error("Error cargando bitácora:", e);
    }
}

function cargarBitacora(data) {
    const tbody = document.querySelector("#tablaBitacora tbody");
    tbody.innerHTML = "";
    data.forEach(log => {
        const fecha = new Date(log.fecha).toLocaleDateString();
        tbody.innerHTML += `
            <tr>
                <td>${log.usuario}</td>
                <td>${fecha}</td>
                <td>${log.accion}</td>
                <td>${log.resultado}</td>
            </tr>`;
    });
}

setInterval(cargarBitacoraDB, 3000);



async function cargarRutasDB() {
    try {
        const res = await fetch("/api/rutas");
        rutas = await res.json();

        const tbody = document.querySelector("#tablaRutas tbody");
        tbody.innerHTML = "";
        rutas.forEach(r => {
            tbody.innerHTML += `
            <tr>
                <td>${r.nombre_ruta || r.nombre}</td>
                <td>${r.origen}</td>
                <td>${r.destino || ""}</td>
                <td>${r.distancia_km || ""}</td>
                <td><button onclick="eliminarRutaDB(${r.id})">Eliminar</button></td>
            </tr>`;
        });

        cargarSelectRutas();
    } catch (e) {
        console.error("Error cargando rutas:", e);
    }
}

async function eliminarRutaDB(id) {
    try {
        await fetch(`/api/rutas/${id}`, { method: "DELETE" });

        const ruta = rutas.find(r => r.id === id);
        const nombreRuta = ruta ? (ruta.nombre_ruta || ruta.nombre) : "Ruta desconocida";

        await registrarBitacora(`Ruta eliminada: ${nombreRuta}`);
        cargarRutasDB();
    } catch (e) {
        console.error("Error eliminando ruta:", e);
    }
}

document.getElementById("btnCrearRuta").addEventListener("click", async () => {
    const nombre = document.getElementById("rutaNombre").value;
    const origen = document.getElementById("rutaOrigen").value;

    if (!nombre || !origen) return alert("Completa los campos");

    try {
        await fetch("/api/rutas", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, origen })
        });

        await registrarBitacora(`Creación ruta ${nombre}`);
        cargarRutasDB();
    } catch (e) {
        console.error(e);
        alert("Error creando ruta");
    }

    document.getElementById("rutaNombre").value = "";
    document.getElementById("rutaOrigen").value = "";
});

async function cargarSelectRutas() {
    const select = document.getElementById("vehRuta");
    select.innerHTML = `<option value="">Seleccionar ruta</option>`;
    rutas.forEach(r => {
        const option = document.createElement("option");
        option.value = r.nombre_ruta || r.nombre;
        option.textContent = r.nombre_ruta || r.nombre;
        select.appendChild(option);
    });
}



async function cargarVehiculosDB() {
    try {
        const res = await fetch("/api/vehiculos");
        vehiculos = await res.json();

        const tbody = document.querySelector("#tablaVehiculos tbody");
        tbody.innerHTML = "";

        vehiculos.forEach(v => {
            tbody.innerHTML += `
            <tr>
                <td>${v.tipo}</td>
                <td>${v.patente}</td>
                <td>${v.numero_ruta}</td>
                <td>${v.conductor}</td>
                <td><button onclick="eliminarVehiculoDB('${v.patente}', '${v.conductor}')">Eliminar</button></td>
            </tr>`;
        });

    } catch (e) {
        console.error("Error cargando vehículos:", e);
    }
}

async function eliminarVehiculoDB(patente, conductor) {
    try {
        const veh = vehiculos.find(v => v.patente === patente && v.conductor === conductor);
        if (!veh) return alert("Vehículo no encontrado");

        await fetch(`/api/vehiculos/${veh.id}`, { method: "DELETE" });
        await registrarBitacora(`Vehículo eliminado: ${patente}`);
        cargarVehiculosDB();

    } catch (e) {
        console.error("Error eliminando vehículo:", e);
    }
}

document.getElementById("btnCrearVeh").addEventListener("click", async () => {
    const tipo = document.getElementById("vehTipo").value.trim();
    const patente = document.getElementById("vehPatente").value.trim();
    const ruta = document.getElementById("vehRuta").value.trim();
    const conductor = document.getElementById("vehConductor").value.trim();

    if (!tipo || !patente || !ruta || !conductor) {
        return alert("Completa todos los campos");
    }

    try {
        await fetch("/api/vehiculos", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ tipo, patente, ruta, conductor })
        });

        await registrarBitacora(`Vehículo ${patente} creado`);
        cargarVehiculosDB();

    } catch (e) {
        console.error(e);
        alert("Error creando vehículo");
    }
});



async function cargarSelectConductores() {
    try {
        const res = await fetch("/api/usuarios");
        usuarios = await res.json();

        const select = document.getElementById("vehConductor");
        select.innerHTML = `<option value="">Seleccionar conductor</option>`;

        usuarios.forEach(u => {
            if (u.rol === "conductor") {
                const option = document.createElement("option");
                option.value = u.username;
                option.textContent = u.username;
                select.appendChild(option);
            }
        });

    } catch (e) {
        console.error("Error cargando conductores:", e);
    }
}

async function cargarConductores() {
    try {
        const res = await fetch("/api/conductores");
        conductores = await res.json();

        const select = document.getElementById("selectConductor");
        select.innerHTML = `<option value="">Seleccionar conductor</option>`;

        conductores.forEach(c => {
            const option = document.createElement("option");
            option.value = c.nombre_usuario;
            option.textContent = c.nombre_usuario;
            select.appendChild(option);
        });

    } catch (e) {
        console.error("Error cargando conductores:", e);
    }
}




async function cargarSeguridad() {
    try {
        const res = await fetch("/api/usuarios");
        usuarios = await res.json();

        const tbody = document.querySelector("#tablaSeguridad tbody");

        const selectedRoles = {};
        usuarios.forEach(u => {
            const sel = document.getElementById(`rol-${u.id}`);
            if (sel) selectedRoles[u.id] = sel.value;
        });

        tbody.innerHTML = "";

        usuarios.forEach(u => {
            tbody.innerHTML += `
            <tr>
                <td>${u.username}</td>
                <td>
                    <select id="rol-${u.id}">
                        <option value="usuario" ${u.rol === "usuario" ? "selected" : ""}>Usuario</option>
                        <option value="conductor" ${u.rol === "conductor" ? "selected" : ""}>Conductor</option>
                        <option value="administrador" ${u.rol === "administrador" ? "selected" : ""}>Admin</option>
                    </select>
                </td>
                <td>
                    <button onclick="guardarRol(${u.id})">Guardar Rol</button>
                    <button onclick="toggleEstado(${u.id}, '${u.estado}', '${u.username}')">
                        ${u.estado === "activo" ? "Bloquear" : "Desbloquear"}
                    </button>
                    <button onclick="eliminarUsuario(${u.id})">Eliminar</button>
                </td>
            </tr>`;
        });

        Object.keys(selectedRoles).forEach(id => {
            const sel = document.getElementById(`rol-${id}`);
            if (sel) sel.value = selectedRoles[id];
        });

    } catch (e) {
        console.error("Error cargando usuarios:", e);
    }
}



async function guardarRol(id) {
    const nuevoRol = document.getElementById(`rol-${id}`).value;

    try {
        const res = await fetch(`/api/usuarios/${id}/rol`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ rol: nuevoRol })
        });

        const data = await res.json();
        alert(data.mensaje || data.error);



   
        cargarSeguridad();

    } catch (e) {
        console.error("Error guardando rol:", e);
    }
}

async function toggleEstado(id, estadoActual, username) {
    const nuevoEstado = estadoActual === "activo" ? "bloqueado" : "activo";

    try {
        await fetch(`/api/usuarios/${id}/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        await registrarBitacora(`Usuario ${username} ${nuevoEstado}`);
        cargarSeguridad();
    } catch (e) {
        console.error("Error actualizando estado:", e);
    }
}

async function eliminarUsuario(id) {
    try {
        await fetch(`/api/usuarios/${id}`, { method: "DELETE" });
        await registrarBitacora(`Usuario eliminado ${id}`);
        cargarSeguridad();
    } catch (e) {
        console.error("Error eliminando usuario:", e);
    }
}




document.getElementById("btnScan").addEventListener("click", () => {
    let errores = [];

    vehiculos.forEach(v => {
        if (!v.numero_ruta) errores.push(`Vehículo ${v.patente} sin ruta asignada`);
        if (!v.conductor) errores.push(`Vehículo ${v.patente} sin conductor`);
    });

    rutas.forEach(r => {
        const asignados = vehiculos.filter(v => v.numero_ruta === (r.nombre_ruta || r.nombre));
        if (asignados.length === 0)
            errores.push(`Ruta ${r.nombre_ruta || r.nombre} no tiene vehículos asignados`);
    });

    const box = document.getElementById("scanResultado");

    if (errores.length === 0) {
        box.textContent = "Sin problemas detectados.";
        box.style.background = "#d1fae5";
    } else {
        box.innerHTML = errores.join("<br>");
        box.style.background = "#fee2e2";
    }
});



document.getElementById("btn-inicio").addEventListener("click", () => {
    window.location.href = "/";
});




setInterval(cargarBitacoraDB, 1000);
setInterval(cargarSeguridad, 8000);

