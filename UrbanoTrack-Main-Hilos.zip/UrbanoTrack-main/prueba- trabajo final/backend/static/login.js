
function registrarBitacora(accion, resultado = "Éxito") {
    let bitacora = JSON.parse(localStorage.getItem("bitacora")) || [];
    const usuarioActual = JSON.parse(localStorage.getItem("usuario"))?.username || "desconocido";
    
    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion,
        resultado
    });

    localStorage.setItem("bitacora", JSON.stringify(bitacora));
}



document.getElementById("btn-login").addEventListener("click", async () => {
  const correo = document.getElementById("correo").value;
  const contrasena = document.getElementById("contrasena").value;
  const mensaje = document.getElementById("mensaje");

  if (!correo || !contrasena) {
    mensaje.textContent = "Completa todos los campos.";
    mensaje.style.color = "orange";
    return;
  }

  const res = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ correo, contrasena })
  });

  let data;
  try {
    data = await res.json();
  } catch {
    mensaje.textContent = "Error inesperado del servidor.";
    mensaje.style.color = "red";
    return;
  }

  
  const estado = data.usuario?.estado;
  if (estado === "bloqueado" || estado === 0 || estado === "0") {
    mensaje.textContent = " Tu cuenta está bloqueada. Habla con el administrador.";
    mensaje.style.color = "red";
    return; 
  }

  if (res.ok) {
    mensaje.textContent = "Bienvenido " + data.usuario.nombre_usuario;
    mensaje.style.color = "green";

    localStorage.setItem("usuario", JSON.stringify(data.usuario));

    if (data.usuario.rol === "administrador") {
      window.location.href = "/panel_admin";
    } else if (data.usuario.rol === "conductor") {
      window.location.href = "/panel_conductor";
    } else {
      window.location.href = "/panel_usuario";
    }
  } else {
    mensaje.textContent = data.error;
    mensaje.style.color = "red";
  }
});
