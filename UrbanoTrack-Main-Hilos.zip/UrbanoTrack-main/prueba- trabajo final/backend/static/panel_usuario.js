let vehiculos = [];
let usuarioActual = JSON.parse(localStorage.getItem("usuario"));


async function registrarBitacora(usuario, accion, resultado = "Éxito") {
    try {
        await fetch("/api/bitacora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usuario, accion, resultado })
        });
    } catch (e) {
        console.error("Error guardando bitácora:", e);
    }
}


if (usuarioActual) {
    registrarBitacora(usuarioActual.nombre_usuario, "Inicio de sesión");
}


async function cargarVehiculos() {
    try {
        const res = await fetch("/api/vehiculos");
        vehiculos = await res.json();
        renderMapa(vehiculos);
        renderLlegadas(vehiculos);
        cargarFiltroRutas();
    } catch (e) {
        console.error("Error cargando vehículos:", e);
    }
}


function renderMapa(lista = vehiculos) {
    const contenedor = document.getElementById("marcadores");
    contenedor.innerHTML = "";

    lista.forEach(v => {
        const marcador = document.createElement("div");
        marcador.classList.add("marcador", v.tipo.toLowerCase());
        const x = v.ubicacion_actual?.x || Math.random() * 80 + 10;
        const y = v.ubicacion_actual?.y || Math.random() * 80 + 10;
        marcador.style.left = `${x}%`;
        marcador.style.top = `${y}%`;
        marcador.title = `${v.tipo} - Ruta ${v.numero_ruta}`;
        marcador.onclick = () => mostrarDetalles(v);
        contenedor.appendChild(marcador);
    });
}


function renderLlegadas(lista = vehiculos) {
    const ul = document.getElementById("lista-llegadas");
    ul.innerHTML = "";
    lista.forEach(v => {
        const li = document.createElement("li");
        const tiempo = Math.floor(Math.random() * 8) + 2;
        li.innerHTML = `<strong>${v.tipo} Ruta ${v.numero_ruta}</strong> — ${tiempo} min`;
        ul.appendChild(li);
    });
}


function mostrarDetalles(v) {
    document.getElementById("tipo").textContent = v.tipo;
    document.getElementById("ruta").textContent = v.numero_ruta;
    document.getElementById("estado").textContent = v.estado;
    document.getElementById("distancia").textContent = v.distancia || "N/A";
    document.getElementById("detalles").classList.remove("oculto");
}

document.getElementById("cerrar-detalles").addEventListener("click", () => {
    document.getElementById("detalles").classList.add("oculto");
});


function cargarFiltroRutas() {
    const select = document.getElementById("filtro-ruta");
    const rutasUnicas = [...new Set(vehiculos.map(v => v.numero_ruta).filter(r => r))];
    select.innerHTML = `<option value="">Todas las rutas</option>`;
    rutasUnicas.forEach(r => {
        const opt = document.createElement("option");
        opt.value = r;
        opt.textContent = r;
        select.appendChild(opt);
    });
}

document.getElementById("filtro-ruta").addEventListener("change", e => {
    const valor = e.target.value;
    const filtrados = valor ? vehiculos.filter(v => v.numero_ruta === valor) : vehiculos;
    renderMapa(filtrados);
    renderLlegadas(filtrados);
});

document.getElementById("buscar").addEventListener("input", e => {
    const texto = e.target.value.toLowerCase();
    const filtrados = vehiculos.filter(v =>
        (v.numero_ruta || "").toLowerCase().includes(texto) || (v.tipo || "").toLowerCase().includes(texto)
    );
    renderMapa(filtrados);
    renderLlegadas(filtrados);
});


document.getElementById("btn-detalles").addEventListener("click", () => {
    const filtro = document.getElementById("filtro-ruta").value;
    if (!filtro) return;
    const filtrados = vehiculos.filter(v => v.numero_ruta === filtro);
    if (filtrados.length > 0) mostrarDetalles(filtrados[0]);
});


document.getElementById("btn-inicio").addEventListener("click", () => {
    if (usuarioActual) registrarBitacora(usuarioActual.nombre_usuario, "Cierre de sesión");
    localStorage.removeItem("usuario");
    window.location.href = "/login";
});


async function verificarEstadoCuenta() {
    if (!usuarioActual) return;
    try {
        const res = await fetch("/api/usuarios");
        const usuarios = await res.json();
        const data = usuarios.find(u => u.id === usuarioActual.id);
        if (!data) {
            mostrarMensajeBloqueo("Tu cuenta ya no existe en el sistema.");
            return;
        }

        if (data.estado === "bloqueado") {
            const msg = document.getElementById("mensaje-bloqueo");
            msg.classList.remove("oculto");
            setTimeout(() => {
                registrarBitacora(usuarioActual.nombre_usuario, "Cierre de sesión (bloqueo)");
                localStorage.removeItem("usuario");
                window.location.href = "/login";
            }, 1000);
        }
    } catch (e) {
        console.error(e);
    }
}


async function refrescarVehiculos() {
    await cargarVehiculos();
    verificarEstadoCuenta();
}



async function refrescarVehiculos() {
    try {
        const res = await fetch("/api/vehiculos");
        vehiculos = await res.json();


        renderMapa(vehiculos);
        renderLlegadas(vehiculos);
        cargarFiltroRutas();


        verificarEstadoCuenta();
    } catch (e) {
        console.error("Error refrescando vehículos:", e);
    }
}

function mostrarMensajeBloqueo(texto) {
    const msg = document.getElementById("mensaje-bloqueo");
    msg.textContent = texto;
    msg.classList.remove("oculto");

    setTimeout(() => {
        localStorage.removeItem("usuarioLogueado");
        window.location.href = "/login";
    }, 2500);
}

cargarVehiculos();
setInterval(refrescarVehiculos, 5000);
