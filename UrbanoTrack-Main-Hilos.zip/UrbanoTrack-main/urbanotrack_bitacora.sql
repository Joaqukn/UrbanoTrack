-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: urbanotrack
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL,
  `accion` text NOT NULL,
  `resultado` varchar(20) DEFAULT 'Éxito',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (145,'test2','2025-12-01 00:00:00','Borrado completo de la bitácora','Éxito'),(146,'test','2025-12-01 00:00:00','Inicio de sesión','Éxito'),(147,'test','2025-12-01 00:00:00','Cierre de sesión','Éxito'),(148,'test5','2025-12-01 00:00:00','Inicio de sesión','Éxito'),(149,'test5','2025-12-01 00:00:00','Vehículo puesto FUERA DE SERVICIO','Éxito'),(150,'test5','2025-12-01 00:00:00','Vehículo puesto EN SERVICIO','Éxito'),(151,'test5','2025-12-01 00:00:00','Inicio de recorrido en TAXI','Éxito'),(152,'test5','2025-12-01 00:00:00','Fin de recorrido en TAXI (0 min)','Éxito'),(153,'test5','2025-12-01 00:00:00','Inicio de recorrido en COLECTIVO','Éxito'),(154,'test5','2025-12-01 00:00:00','Fin de recorrido en COLECTIVO (0 min)','Éxito'),(155,'test5','2025-12-01 00:00:00','Cierre de sesión','Éxito'),(156,'test5','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(157,'test2','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(158,'test5','2025-12-01 00:00:00','Usuario test5 activo','Éxito'),(159,'test2','2025-12-01 00:00:00','Usuario test5 desbloqueado','Éxito'),(160,'test5','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(161,'test2','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(162,'test5','2025-12-01 00:00:00','Usuario test5 activo','Éxito'),(163,'test2','2025-12-01 00:00:00','Usuario test5 desbloqueado','Éxito'),(164,'test','2025-12-01 00:00:00','Inicio de sesión','Éxito'),(165,'test','2025-12-01 00:00:00','Usuario test bloqueado','Éxito'),(166,'test2','2025-12-01 00:00:00','Usuario test bloqueado','Éxito'),(167,'test','2025-12-01 00:00:00','Cierre de sesión (bloqueo)','Éxito'),(168,'test5','2025-12-01 00:00:00','Inicio de sesión','Éxito'),(169,'test','2025-12-01 00:00:00','Usuario test activo','Éxito'),(170,'test2','2025-12-01 00:00:00','Usuario test desbloqueado','Éxito'),(171,'test5','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(172,'test2','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(173,'test5','2025-12-01 00:00:00','Cierre de sesión','Éxito'),(174,'test5','2025-12-01 00:00:00','Usuario test5 activo','Éxito'),(175,'test2','2025-12-01 00:00:00','Usuario test5 desbloqueado','Éxito'),(176,'test5','2025-12-01 00:00:00','Inicio de sesión','Éxito'),(177,'test5','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(178,'test2','2025-12-01 00:00:00','Usuario test5 bloqueado','Éxito'),(179,'test5','2025-12-01 00:00:00','Usuario test5 activo','Éxito'),(180,'test2','2025-12-01 00:00:00','Usuario test5 desbloqueado','Éxito'),(181,'test5','2025-12-01 00:00:00','Cierre de sesión','Éxito');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 11:50:21
