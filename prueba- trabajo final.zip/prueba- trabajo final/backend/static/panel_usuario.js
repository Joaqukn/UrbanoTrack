
let vehiculos = [];
let bitacora = JSON.parse(localStorage.getItem("bitacora")) || [];
let usuarioActual = JSON.parse(localStorage.getItem("usuario")); 

if (usuarioActual) {
    bitacora.push({
        usuario: usuarioActual.nombre_usuario,
        fecha: new Date().toISOString(),
        accion: "Inicio de sesión",
        resultado: "Éxito"
    });
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
}


async function cargarVehiculos() {
    try {
        const res = await fetch("/api/vehiculos");
        vehiculos = await res.json();
        renderMapa(vehiculos);
        renderLlegadas(vehiculos);
        cargarFiltroRutas(); 
    } catch (e) {
        console.error("Error cargando vehículos:", e);
    }
}


function renderMapa(lista = vehiculos) {
    const contenedor = document.getElementById("marcadores");
    contenedor.innerHTML = "";

    lista.forEach(v => {
        const marcador = document.createElement("div");
        marcador.classList.add("marcador", v.tipo.toLowerCase());

 
        const x = v.ubicacion_actual?.x || Math.random() * 80 + 10;
        const y = v.ubicacion_actual?.y || Math.random() * 80 + 10;

        marcador.style.left = `${x}%`;
        marcador.style.top = `${y}%`;
        marcador.title = `${v.tipo} - Ruta ${v.numero_ruta}`;
        marcador.onclick = () => mostrarDetalles(v);
        contenedor.appendChild(marcador);
    });
}


function renderLlegadas(lista = vehiculos) {
    const ul = document.getElementById("lista-llegadas");
    ul.innerHTML = "";
    lista.forEach(v => {
        const li = document.createElement("li");
        const tiempo = Math.floor(Math.random() * 8) + 2;
        li.innerHTML = `<strong>${v.tipo} Ruta ${v.numero_ruta}</strong> — ${tiempo} min`;
        ul.appendChild(li);
    });
}


function mostrarDetalles(v) {
    document.getElementById("tipo").textContent = v.tipo;
    document.getElementById("ruta").textContent = v.numero_ruta; // <-- ruta correcta
    document.getElementById("estado").textContent = v.estado;
    document.getElementById("distancia").textContent = v.distancia || "N/A";
    document.getElementById("detalles").classList.remove("oculto");
}

document.getElementById("cerrar-detalles").addEventListener("click", () => {
    document.getElementById("detalles").classList.add("oculto");
});


function cargarFiltroRutas() {
    const select = document.getElementById("filtro-ruta");
    const rutasUnicas = [...new Set(vehiculos.map(v => v.numero_ruta).filter(r => r))];
    select.innerHTML = `<option value="">Todas las rutas</option>`;
    rutasUnicas.forEach(r => {
        const opt = document.createElement("option");
        opt.value = r;
        opt.textContent = r;
        select.appendChild(opt);
    });
}

document.getElementById("filtro-ruta").addEventListener("change", e => {
    const valor = e.target.value;
    const filtrados = valor ? vehiculos.filter(v => v.numero_ruta === valor) : vehiculos;
    renderMapa(filtrados);
    renderLlegadas(filtrados);
});


document.getElementById("buscar").addEventListener("input", e => {
    const texto = e.target.value.toLowerCase();
    const filtrados = vehiculos.filter(v =>
        (v.numero_ruta || "").toLowerCase().includes(texto) || (v.tipo || "").toLowerCase().includes(texto)
    );
    renderMapa(filtrados);
    renderLlegadas(filtrados);
});


document.getElementById("btn-detalles").addEventListener("click", () => {
    const filtro = document.getElementById("filtro-ruta").value;
    if (!filtro) {
        alert("Selecciona una ruta para ver los detalles");
        return;
    }
    const filtrados = vehiculos.filter(v => v.numero_ruta === filtro);
    if (filtrados.length === 0) {
        alert("No hay vehículos activos en esta ruta");
        return;
    }
    mostrarDetalles(filtrados[0]);
});


document.getElementById("btn-inicio").addEventListener("click", () => {
    if (usuarioActual) {
        bitacora.push({
            usuario: usuarioActual.nombre_usuario,
            fecha: new Date().toISOString(),
            accion: "Cierre de sesión",
            resultado: "Éxito"
        });
        localStorage.setItem("bitacora", JSON.stringify(bitacora));
    }

    localStorage.removeItem("usuario");
    window.location.href = "/login";
});


async function verificarEstadoCuenta() {
    try {
        if (!usuarioActual) return;

        const res = await fetch(`/api/usuarios/${usuarioActual.id}`);
        const data = await res.json();

        if (data.estado === "bloqueado") {
            const msg = document.getElementById("mensaje-bloqueo");
            msg.classList.remove("oculto");

            setTimeout(() => {
                bitacora.push({
                    usuario: usuarioActual.nombre_usuario,
                    fecha: new Date().toISOString(),
                    accion: "Cierre de sesión (bloqueo)",
                    resultado: "Éxito"
                });
                localStorage.setItem("bitacora", JSON.stringify(bitacora));

                localStorage.removeItem("usuario");
                window.location.href = "/login";
            }, 2500);
        }
    } catch (e) {
        console.error("Error verificando estado:", e);
    }
}


cargarVehiculos();
setInterval(verificarEstadoCuenta, 5000);
verificarEstadoCuenta();
