    
let bitacora = JSON.parse(localStorage.getItem("bitacora")) || [];
let usuarioActual = localStorage.getItem("usuarioLogueado") || null;


async function inicializarUsuario() {
    if (!usuarioActual) {
        try {
            const res = await fetch("/api/usuarios");
            if (!res.ok) throw new Error("No se pudo cargar usuarios");
            const users = await res.json();
            if (users.length > 0) {
                usuarioActual = users[0].username;
            } else {
                usuarioActual = "admin";
            }
            localStorage.setItem("usuarioLogueado", usuarioActual);
        } catch (e) {
            console.error("Error cargando usuarios:", e);
            usuarioActual = "admin";
            localStorage.setItem("usuarioLogueado", usuarioActual);
        }
    }
    inicializar(); 
}

inicializarUsuario();

async function inicializar() {
    await cargarRutasDB();
    await cargarVehiculosDB();
    await cargarSeguridad();
    await cargarBitacora();
    await cargarSelectConductores();
    await cargarConductores();
    
}


function guardarDatos() {
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
}


let rutas = [];
let vehiculos = [];
let usuarios = [];


const sidebarLinks = document.querySelectorAll(".sidebar a");
const sections = document.querySelectorAll(".panel-section");

sidebarLinks.forEach(link => {
    link.addEventListener("click", () => {
        sidebarLinks.forEach(l => l.classList.remove("active"));
        link.classList.add("active");

        sections.forEach(sec => sec.classList.remove("active"));
        document.getElementById(link.dataset.section).classList.add("active");
    });
});

async function cargarRutasDB() {
    try {
        const res = await fetch("/api/rutas");
        rutas = await res.json();

        
        if (rutas.length === 0) {
            const testRuta = { nombre: "Centro-Norte", origen: "Centro", destino: "Norte", distancia_km: 12.5 };
            const crear = await fetch("/api/rutas", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(testRuta)
            });
            if (crear.ok) rutas.push(testRuta);
        }

        const tbody = document.querySelector("#tablaRutas tbody");
        tbody.innerHTML = "";
        rutas.forEach(r => {
            tbody.innerHTML += `
            <tr>
                <td>${r.nombre_ruta || r.nombre}</td>
                <td>${r.origen}</td>
                <td>${r.destino || ""}</td>
                <td>${r.distancia_km || ""}</td>
                <td><button onclick="eliminarRutaDB(${r.id})">Eliminar</button></td>
            </tr>`;
        });
        cargarSelectRutas();
    } catch (e) {
        console.error("Error cargando rutas:", e);
    }
}


async function cargarVehiculosDB() {
    try {
        const res = await fetch("/api/vehiculos");
        vehiculos = await res.json();

        const tbody = document.querySelector("#tablaVehiculos tbody");
        tbody.innerHTML = "";

        vehiculos.forEach(v => {
            const tipo = v.tipo || "";
            const patente = v.patente || "";
            const ruta = v.numero_ruta || "Sin ruta"; 
            const conductor = v.conductor || "Sin conductor";
            const estado = v.estado || "";

            tbody.innerHTML += `
            <tr>
                <td>${tipo}</td>
                <td>${patente}</td>
                <td>${ruta}</td>
                <td>${conductor}</td>
                <td>
                    <button onclick="eliminarVehiculoDB('${patente}', '${conductor}')">Eliminar</button>
                </td>
            </tr>`;
        });
    } catch (e) {
        console.error("Error cargando vehículos:", e);
    }
}




document.getElementById("btnCrearVeh").addEventListener("click", async () => {
    const tipo = document.getElementById("vehTipo").value;
    const patente = document.getElementById("vehPatente").value;
    const ruta = document.getElementById("vehRuta").value;
    const selectConductor = document.getElementById("vehConductor");

    // Validar que exista una opción seleccionada
    if (!tipo || !patente || !ruta || !selectConductor.selectedOptions[0]) {
        return alert("Completa todos los campos correctamente");
    }

    const conductorNombre = selectConductor.selectedOptions[0].textContent;

    try {
        const res = await fetch("/api/vehiculos", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                tipo,
                patente,
                ruta,
                conductor: conductorNombre
            })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Error al crear vehículo");

        bitacora.push({
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: `Vehículo ${patente} asignado a ${ruta}`,
            resultado: "Éxito"
        });
        guardarDatos();
        cargarVehiculosDB();
        cargarBitacora();
    } catch (e) {
        console.error(e);
        alert("Error creando vehículo: " + e.message);
    }

    // Limpiar campos
    document.getElementById("vehTipo").value = "";
    document.getElementById("vehPatente").value = "";
    document.getElementById("vehRuta").value = "";
    document.getElementById("vehConductor").value = "";
});


async function cargarSelectRutas() {
    const select = document.getElementById("vehRuta");
    select.innerHTML = `<option value="">Seleccionar ruta</option>`;
    rutas.forEach(r => {
        const option = document.createElement("option");
        option.value = r.nombre_ruta || r.nombre;
        option.textContent = r.nombre_ruta || r.nombre;
        select.appendChild(option);
    });
}

async function cargarSelectConductores() {
    try {
        const res = await fetch("/api/usuarios");
        usuarios = await res.json();
        const select = document.getElementById("vehConductor");
        select.innerHTML = `<option value="">Seleccionar conductor</option>`;
        usuarios.forEach(u => {
            if (u.rol === "conductor") {
                const option = document.createElement("option");
                option.value = u.username; 
                option.textContent = u.username;
                select.appendChild(option);
            }
        });
    } catch (e) {
        console.error("Error cargando conductores:", e);
    }
}


function cargarBitacora(data = bitacora) {
    const tbody = document.querySelector("#tablaBitacora tbody");
    tbody.innerHTML = "";
    data.forEach(log => {
        tbody.innerHTML += `
        <tr>
            <td>${log.usuario}</td>
            <td>${log.fecha}</td>
            <td>${log.accion}</td>
            <td>${log.resultado}</td>
        </tr>`;
    });
}


document.getElementById("btnCrearRuta").addEventListener("click", async () => {
    const nombre = document.getElementById("rutaNombre").value;
    const origen = document.getElementById("rutaOrigen").value;
    if (!nombre || !origen) return alert("Completa los campos");

    try {
        const res = await fetch("/api/rutas", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, origen })
        });
        if (!res.ok) throw new Error("Error creando ruta");

        bitacora.push({
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: `Creación ruta ${nombre}`,
            resultado: "Éxito"
        });
        guardarDatos();
        cargarRutasDB();
        cargarBitacora();
    } catch (e) {
        console.error(e);
        alert("Error creando ruta");
    }

    document.getElementById("rutaNombre").value = "";
    document.getElementById("rutaOrigen").value = "";
});


async function eliminarVehiculoDB(patente, conductor) {
    try {

        const veh = vehiculos.find(v => v.patente === patente && v.conductor === conductor);
        if (!veh) return alert("Vehículo no encontrado");

        await fetch(`/api/vehiculos/${veh.id}`, { method: "DELETE" });

        bitacora.push({
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: `Vehículo eliminado: ${patente} - Conductor: ${conductor}`,
            resultado: "Éxito"
        });
        guardarDatos();
        cargarVehiculosDB();
        cargarBitacora();
    } catch (e) {
        console.error("Error eliminando vehículo:", e);
        alert("Error eliminando vehículo");
    }
}

async function eliminarRutaDB(id) {
    await fetch(`/api/rutas/${id}`, { method: "DELETE" });
    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Ruta eliminada ${id}`,
        resultado: "Éxito"
    });
    guardarDatos();
    cargarRutasDB();
    cargarBitacora();


async function cargarSeguridad() {
    try {
        const res = await fetch("/api/usuarios");
        usuarios = await res.json();
        const tbody = document.querySelector("#tablaSeguridad tbody");
        tbody.innerHTML = "";
        usuarios.forEach(u => {
            tbody.innerHTML += `<tr>
                <td>${u.username}</td>
                <td>${u.estado}</td>
                <td>
                    <button onclick="toggleEstado(${u.id}, '${u.estado}', '${u.username}')">
                        ${u.estado === "activo" ? "Bloquear" : "Desbloquear"}
                    </button>
                    <button onclick="eliminarUsuario(${u.id})">Eliminar</button>
                </td>
            </tr>`;
        });
    } catch (e) {
        console.error("Error cargando usuarios:", e);
    }
}


async function toggleEstado(id, estadoActual, username) {
    const nuevoEstado = estadoActual === "activo" ? "bloqueado" : "activo";
    try {
        const res = await fetch(`/api/usuarios/${id}/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado: nuevoEstado })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ error: 'error' }));
            alert("Error actualizando estado: " + (err.error || res.status));
            return;
        }

        bitacora.push({
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: `Usuario ${username} ${nuevoEstado === "activo" ? "desbloqueado" : "bloqueado"}`,
            resultado: "Éxito"
        });
        guardarDatos();
        cargarBitacora();
        cargarSeguridad();
    } catch (e) {
        console.error("fetch error", e);
        alert("Error de conexión al actualizar estado");
    }
}

async function eliminarUsuario(id) {
    await fetch(`/api/usuarios/${id}`, { method: "DELETE" });

    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Usuario eliminado ${id}`,
        resultado: "Éxito"
    });
    guardarDatos();
    cargarBitacora();
    cargarSeguridad();
}


document.getElementById("btnFiltrarBitacora").addEventListener("click", () => {
    const fecha = document.getElementById("filtroFecha").value;
    const usuario = document.getElementById("filtroUsuario").value.toLowerCase();
    const filtrado = bitacora.filter(log => {
        return (
            (!fecha || log.fecha === fecha) &&
            (!usuario || log.usuario.toLowerCase().includes(usuario))
        );
    });
    cargarBitacora(filtrado);
});


document.getElementById("btnScan").addEventListener("click", () => {
    let errores = [];

    vehiculos.forEach(v => {
        if (!v.numero_ruta) errores.push(`Vehículo ${v.patente} no tiene ruta asignada`);
        if (!v.conductor) errores.push(`Vehículo ${v.patente} no tiene conductor`);
    });

    rutas.forEach(r => {
        const asignados = vehiculos.filter(v => v.numero_ruta === (r.nombre_ruta || r.nombre));
        if (asignados.length === 0)
            errores.push(`Ruta ${r.nombre_ruta || r.nombre} no tiene vehículos asignados`);
    });

    const box = document.getElementById("scanResultado");
    if (errores.length === 0) {
        box.textContent = "Sin problemas detectados.";
        box.style.background = "#d1fae5";
    } else {
        box.innerHTML = errores.join("<br>");
        box.style.background = "#fee2e2";
    }
});

async function cargarConductores() {
    try {
        const res = await fetch("/api/conductores");
        conductores = await res.json();

        const select = document.getElementById("selectConductor");
        select.innerHTML = ""; // vaciar opciones
        select.innerHTML = '<option value="">Seleccionar conductor</option>';

        conductores.forEach(c => {
            const option = document.createElement("option");
            option.value = c.nombre_usuario; // guardamos el nombre
            option.textContent = c.nombre_usuario;
            select.appendChild(option);
        });
    } catch (e) {
        console.error("Error cargando conductores:", e);
    }
}


document.getElementById("btn-inicio").addEventListener("click", () => {
    window.location.href = "/";
});

function guardarBitacora() {
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
    cargarBitacora(bitacora);
}


document.getElementById("btnResetBitacora").addEventListener("click", () => {
    if (confirm("¿Querés borrar toda la bitácora? Esta acción no se puede deshacer.")) {
  
        bitacora = [];
        localStorage.removeItem("bitacora");

     
        const logBorrado = {
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: "Borrado completo de la bitácora",
            resultado: "Éxito"
        };
        bitacora.push(logBorrado);

      
        guardarBitacora();
        alert("Bitácora borrada y registro agregado correctamente.");
    }
});


document.getElementById("btnFiltrarBitacora").addEventListener("click", () => {
    const fecha = document.getElementById("filtroFecha").value;
    const usuario = document.getElementById("filtroUsuario").value.toLowerCase();

    // Leer siempre desde memoria
    const filtrado = bitacora.filter(log => {
        return (
            (!fecha || log.fecha === fecha) &&
            (!usuario || log.usuario.toLowerCase().includes(usuario))
        );
    });
    cargarBitacora(filtrado);
});


function actualizarBitacoraAuto() {
    setInterval(() => {

        bitacora = JSON.parse(localStorage.getItem("bitacora")) || [];
        cargarBitacora(bitacora);
    }, 3000); // cada 3 segundos
}

actualizarBitacoraAuto();

async function ponerVehiculosEnServicio() {
    habilitado = true;

    
    const res = await fetch(`/api/vehiculos/usuario/${usuarioActual}`);
    const vehiculosUsuario = await res.json();

    for (let v of vehiculosUsuario) {
        
        await fetch(`/api/vehiculos/${v.id}/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado: "En servicio" })
        });

        
        await fetch("/api/bitacora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                usuario: usuarioActual,
                accion: `Vehículo ${v.patente} puesto EN SERVICIO`,
                resultado: "Éxito"
            })
        });
    }

    cargarVehiculosUsuario();
    cargarBitacora();         
}

async function ponerVehiculosFueraServicio() {
    habilitado = false;

    const res = await fetch(`/api/vehiculos/usuario/${usuarioActual}`);
    const vehiculosUsuario = await res.json();

    for (let v of vehiculosUsuario) {
        await fetch(`/api/vehiculos/${v.id}/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado: "Fuera de servicio" })
        });

        await fetch("/api/bitacora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                usuario: usuarioActual,
                accion: `Vehículo ${v.patente} puesto FUERA DE SERVICIO`,
                resultado: "Éxito"
            })
        });
    }

    cargarVehiculosUsuario();
    cargarBitacora();
}}
