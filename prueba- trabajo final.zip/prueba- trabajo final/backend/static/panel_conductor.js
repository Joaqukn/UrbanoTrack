
let intervaloMovimiento = null;
let inicioRecorrido = null;
let distanciaRecorrida = 0;

let tipoVehiculo = null;
let habilitado = false; 


let vehiculo = {
    x: randomPos(),
    y: randomPos(),
    activo: false,
    ruta: "Sin asignar",
    patente: "XXX000",
    estado: "Fuera de servicio"
};


let otrosVehiculos = [
    { x: randomPos(), y: randomPos(), color: "azul" },
    { x: randomPos(), y: randomPos(), color: "amarillo" }
];

const marcador = document.getElementById("marcadorVehiculo");
const contenedorSimulados = document.getElementById("otrosVehiculos");
const resumen = document.getElementById("resumenRecorrido");


let bitacora = JSON.parse(localStorage.getItem("bitacora")) || [];
let usuarioActual = JSON.parse(localStorage.getItem("usuarioLogueado")) || { nombre_usuario: "Conductor" };


function randomPos() { return Math.random() * 80 + 10; }

function actualizarMarcador() {
    marcador.style.display = vehiculo.activo ? "block" : "none";
    marcador.style.left = vehiculo.x + "%";
    marcador.style.top = vehiculo.y + "%";
}


function moverVehiculo() {
    if (!vehiculo.activo) return;

    let oldX = vehiculo.x;
    let oldY = vehiculo.y;

    vehiculo.x += (Math.random() - 0.5) * 5;
    vehiculo.y += (Math.random() - 0.5) * 5;

    distanciaRecorrida += Math.sqrt(Math.pow(vehiculo.x - oldX, 2) + Math.pow(vehiculo.y - oldY, 2));

    vehiculo.x = Math.max(10, Math.min(90, vehiculo.x));
    vehiculo.y = Math.max(10, Math.min(90, vehiculo.y));

    actualizarMarcador();
}

function moverVehiculosSimulados() {
    contenedorSimulados.innerHTML = "";
    otrosVehiculos.forEach(v => {
        v.x += (Math.random() - 0.5) * 4;
        v.y += (Math.random() - 0.5) * 4;

        v.x = Math.max(10, Math.min(90, v.x));
        v.y = Math.max(10, Math.min(90, v.y));

        const div = document.createElement("div");
        div.classList.add("marker", v.color);
        div.style.left = v.x + "%";
        div.style.top = v.y + "%";
        contenedorSimulados.appendChild(div);
    });
}


function bloquearRecorrido() {
    document.getElementById("btnIniciar").disabled = true;
    document.getElementById("btnTerminar").disabled = true;
    clearInterval(intervaloMovimiento);
}

function habilitarRecorrido() {
    document.getElementById("btnIniciar").disabled = false;
    document.getElementById("btnTerminar").disabled = false;
}


document.getElementById("btnServicio").addEventListener("click", () => {
    habilitado = true;
    vehiculo.estado = "En servicio";
    document.getElementById("estadoVehiculo").textContent = "En servicio";
    habilitarRecorrido();
    actualizarVehiculosLista();

    bitacora.push({
        usuario: usuarioActual.nombre_usuario,
        fecha: new Date().toISOString(),
        accion: "Vehículo puesto EN SERVICIO",
        resultado: "Éxito"
    });
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
});


document.getElementById("btnFuera").addEventListener("click", () => {
    habilitado = false;
    vehiculo.estado = "Fuera de servicio";
    vehiculo.activo = false;
    document.getElementById("estadoVehiculo").textContent = "Fuera de servicio";
    bloquearRecorrido();
    marcador.style.display = "none";
    actualizarVehiculosLista();

    bitacora.push({
        usuario: usuarioActual.nombre_usuario,
        fecha: new Date().toISOString(),
        accion: "Vehículo puesto FUERA DE SERVICIO",
        resultado: "Éxito"
    });
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
});


document.getElementById("btnIniciar").addEventListener("click", () => {
    if (!habilitado) return alert("El vehículo debe estar EN SERVICIO para iniciar recorrido.");
    document.getElementById("modalVehiculo").style.display = "flex";
});


document.querySelectorAll(".seleccion").forEach(btn => {
    btn.addEventListener("click", e => {
        tipoVehiculo = e.target.dataset.tipo;
        marcador.className = "marker " + (tipoVehiculo === "taxi" ? "amarillo" : "azul");
        document.getElementById("modalVehiculo").style.display = "none";

        vehiculo.activo = true;
        distanciaRecorrida = 0;
        inicioRecorrido = new Date();
        vehiculo.tipo = tipoVehiculo;

        actualizarMarcador();
        actualizarVehiculosLista();

        bitacora.push({
            usuario: usuarioActual.nombre_usuario,
            fecha: new Date().toISOString(),
            accion: `Inicio de recorrido en ${tipoVehiculo.toUpperCase()}`,
            resultado: "Éxito"
        });
        localStorage.setItem("bitacora", JSON.stringify(bitacora));

        intervaloMovimiento = setInterval(() => {
            moverVehiculo();
            moverVehiculosSimulados();
        }, 1500);
    });
});


document.getElementById("btnTerminar").addEventListener("click", () => {
    if (!vehiculo.activo) return;

    vehiculo.activo = false;
    clearInterval(intervaloMovimiento);
    marcador.style.display = "none";

    let fin = new Date();
    let duracion = Math.round((fin - inicioRecorrido) / 60000);

    resumen.style.display = "block";
    resumen.innerHTML = `
        <h3>Resumen del viaje</h3>
        <p><strong>Vehículo:</strong> ${tipoVehiculo === "taxi" ? "Taxi" : "Colectivo"}</p>
        <p><strong>Ruta:</strong> ${vehiculo.ruta}</p>
        <p><strong>Inicio:</strong> ${inicioRecorrido.toLocaleTimeString()}</p>
        <p><strong>Fin:</strong> ${fin.toLocaleTimeString()}</p>
        <p><strong>Duración:</strong> ${duracion} min</p>
        <p><strong>Distancia recorrida:</strong> ${distanciaRecorrida.toFixed(2)} unidades</p>
    `;

    bitacora.push({
        usuario: usuarioActual.nombre_usuario,
        fecha: new Date().toISOString(),
        accion: `Fin de recorrido en ${tipoVehiculo.toUpperCase()} (${duracion} min)`,
        resultado: "Éxito"
    });
    localStorage.setItem("bitacora", JSON.stringify(bitacora));

    actualizarVehiculosLista();
});


function actualizarVehiculosLista() {
    const tabla = document.getElementById("tablaVehiculos");
    if (!tabla) return;

    tabla.innerHTML = `
        <tr>
            <td>${vehiculo.tipo || "Sin asignar"}</td>
            <td>${vehiculo.patente}</td>
            <td>${vehiculo.ruta}</td>
            <td>${usuarioActual.nombre_usuario}</td>
            <td>${vehiculo.estado}</td>
        </tr>
    `;
}


if (usuarioActual && usuarioActual.nombre_usuario) {
    bitacora.push({
        usuario: usuarioActual.nombre_usuario,
        fecha: new Date().toISOString(),
        accion: "Inicio de sesión",
        resultado: "Éxito"
    });
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
    console.log(`✅ ${usuarioActual.nombre_usuario} inició sesión`);
}

document.getElementById("btnLogout")?.addEventListener("click", () => {
    if (usuarioActual && usuarioActual.nombre_usuario) {
        bitacora.push({
            usuario: usuarioActual.nombre_usuario,
            fecha: new Date().toISOString(),
            accion: "Cierre de sesión",
            resultado: "Éxito"
        });
        localStorage.setItem("bitacora", JSON.stringify(bitacora));
        console.log(`⚠️ ${usuarioActual.nombre_usuario} cerró sesión`);
    }

    localStorage.removeItem("usuarioLogueado");
    window.location.href = "/login";
});
