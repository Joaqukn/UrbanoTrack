document.getElementById("btn-registro").addEventListener("click", async () => {
  const nombre_usuario = document.getElementById("nombre_usuario").value;
  const correo = document.getElementById("correo").value;
  const contrasena = document.getElementById("contrasena").value;
  const rol = document.getElementById("rol").value;
  const mensaje = document.getElementById("mensaje");

  if (!nombre_usuario || !correo || !contrasena) {
    mensaje.textContent = "⚠️ Completa todos los campos.";
    mensaje.style.color = "orange";
    return;
  }

  const res = await fetch("http://127.0.0.1:5000/api/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nombre_usuario, correo, contrasena, rol })
  });

  let data;
  try {
    data = await res.json();
  } catch {
    mensaje.textContent = "⚠️ Error inesperado del servidor.";
    mensaje.style.color = "red";
    return;
  }

  if (res.ok) {
    mensaje.textContent = "Registro exitoso. Redirigiendo al login...";
    mensaje.style.color = "green";
    setTimeout(() => window.location.href = "/login", 2000);
  } else {
    mensaje.textContent = data.error || "Error en el registro.";
    mensaje.style.color = "red";
  }
});
