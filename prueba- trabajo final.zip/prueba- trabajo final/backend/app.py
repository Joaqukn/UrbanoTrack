from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import bcrypt
import db

app = Flask(__name__)
CORS(app)



@app.route('/')
def index():
    return render_template("index.html")


@app.route('/login', endpoint="login")
def login_page():
    return render_template("login.html")


@app.route('/register', endpoint="register")
def register_page():
    return render_template("register.html")


@app.route('/panel_usuario', endpoint="panel_usuario")
def panel_usuario():
    return render_template("panel_usuario.html")


@app.route('/panel_admin', endpoint="panel_admin")
def panel_admin():
    return render_template("panel_admin.html")


@app.route('/panel_conductor', endpoint="panel_conductor")
def panel_conductor():
    return render_template("panel_conductor.html")


@app.before_request
def mostrar_ip():
    print(f"Conexión desde: {request.remote_addr}")



@app.route("/api/register", methods=["POST"], endpoint="api_register")
def register():
    data = request.json
    nombre_usuario = data.get("nombre_usuario")
    correo = data.get("correo")
    contrasena = data.get("contrasena")
    rol = data.get("rol", "pasajero")

    if not nombre_usuario or not correo or not contrasena:
        return jsonify({"error": "Faltan campos"}), 400

    hashed = bcrypt.hashpw(contrasena.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    conexion = db.get_connection()
    cursor = conexion.cursor()
    try:
        cursor.execute(
            "INSERT INTO usuarios (nombre_usuario, correo, contrasena, rol) VALUES (%s, %s, %s, %s)",
            (nombre_usuario, correo, hashed, rol)
        )
        conexion.commit()
        return jsonify({"mensaje": "Usuario registrado correctamente"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    finally:
        cursor.close()
        conexion.close()


@app.route("/api/login", methods=["POST"], endpoint="api_login")
def login():
    data = request.json
    correo = data.get("correo")
    contrasena = data.get("contrasena")

    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM usuarios WHERE correo = %s", (correo,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        conexion.close()
        return jsonify({"error": "Correo o contraseña incorrectos"}), 401

    if usuario["estado"] == "bloqueado":
        conexion.close()
        return jsonify({"error": "Tu cuenta está bloqueada"}), 403

    if not bcrypt.checkpw(contrasena.encode('utf-8'), usuario["contrasena"].encode('utf-8')):
        conexion.close()
        return jsonify({"error": "Correo o contraseña incorrectos"}), 401

    conexion.close()
    return jsonify({
        "mensaje": "Login exitoso",
        "usuario": {
            "id": usuario["id"],
            "nombre_usuario": usuario["nombre_usuario"],
            "rol": usuario["rol"],
            "estado": usuario["estado"]
        }
    })



@app.route("/api/usuarios", methods=["GET"])
def api_usuarios():
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT id, nombre_usuario AS username, rol, estado FROM usuarios")
    usuarios = cursor.fetchall()
    cursor.close()
    conexion.close()
    return jsonify(usuarios)


@app.route("/api/usuarios/<int:id>/estado", methods=["PUT"])
def actualizar_estado_usuario(id):
    data = request.get_json() or {}
    nuevo_estado = data.get("estado")
    if nuevo_estado not in ["activo", "bloqueado"]:
        return jsonify({"error": "Estado inválido"}), 400

    conexion = db.get_connection()
    cursor = conexion.cursor()
    try:
        cursor.execute("UPDATE usuarios SET estado = %s WHERE id = %s", (nuevo_estado, id))
        conexion.commit()
        return jsonify({"mensaje": "Estado actualizado"}), 200
    except Exception as e:
        return jsonify({"error": "Error al actualizar estado"}), 500
    finally:
        cursor.close()
        conexion.close()


@app.route("/api/usuarios/<int:id>", methods=["GET", "DELETE"])
def manejar_usuario(id):
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)

    if request.method == "GET":
        cursor.execute("SELECT id, nombre_usuario, estado, rol FROM usuarios WHERE id = %s", (id,))
        usuario = cursor.fetchone()
        cursor.close()
        conexion.close()
        if usuario:
            return jsonify(usuario)
        else:
            return jsonify({"error": "Usuario no encontrado"}), 404
    else:  
        cursor.close()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM usuarios WHERE id=%s", (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        return jsonify({"status": "ok"})



@app.route("/api/rutas", methods=["GET", "POST"])
def api_rutas():
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)

    if request.method == "GET":
        cursor.execute("SELECT id, nombre_ruta AS nombre, origen FROM rutas")
        rutas = cursor.fetchall()
        cursor.close()
        conexion.close()
        return jsonify(rutas)

    data = request.get_json()
    nombre = data.get("nombre")
    origen = data.get("origen")
    if not nombre or not origen:
        return jsonify({"error": "Faltan campos"}), 400
    try:
        cursor.execute("INSERT INTO rutas (nombre_ruta, origen) VALUES (%s, %s)", (nombre, origen))
        conexion.commit()
        return jsonify({"mensaje": "Ruta creada"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conexion.close()


@app.route("/api/rutas/<int:id>", methods=["DELETE"])
def api_eliminar_ruta(id):
    conexion = db.get_connection()
    cursor = conexion.cursor()
    try:
        cursor.execute("DELETE FROM rutas WHERE id=%s", (id,))
        conexion.commit()
        return jsonify({"mensaje": "Ruta eliminada"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conexion.close()



@app.route("/api/vehiculos", methods=["GET", "POST"])
def api_vehiculos():
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)

    try:
        if request.method == "GET":
 
            cursor.execute("""
                SELECT v.id, v.tipo, v.patente, r.nombre_ruta AS numero_ruta,
                       v.conductor, v.estado, v.ubicacion_actual
                FROM vehiculos v
                LEFT JOIN rutas r ON v.numero_ruta = r.id
            """)
            vehiculos = cursor.fetchall()
            return jsonify(vehiculos)

    
        data = request.get_json()
        tipo = data.get("tipo")
        patente = data.get("patente")
        ruta_nombre = data.get("ruta")
        conductor_nombre = data.get("conductor")

        if not tipo or not patente or not ruta_nombre or not conductor_nombre:
            return jsonify({"error": "Faltan campos"}), 400

   
        cursor.execute("SELECT id FROM rutas WHERE nombre_ruta=%s", (ruta_nombre,))
        res_ruta = cursor.fetchone()
        if not res_ruta:
            return jsonify({"error": "Ruta no encontrada"}), 404
        id_ruta = res_ruta["id"]

      
        cursor.execute("""
            INSERT INTO vehiculos (tipo, patente, numero_ruta, conductor, estado)
            VALUES (%s, %s, %s, %s, 'en servicio')
        """, (tipo, patente, id_ruta, conductor_nombre))
        conexion.commit()
        return jsonify({"mensaje": "Vehículo creado"}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conexion.close()

@app.route("/api/vehiculos/<int:id>", methods=["DELETE"])
def api_eliminar_vehiculo(id):
    conexion = db.get_connection()
    cursor = conexion.cursor()
    try:
        cursor.execute("DELETE FROM vehiculos WHERE id=%s", (id,))
        conexion.commit()
        return jsonify({"mensaje": "Vehículo eliminado"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conexion.close()



@app.route("/api/conductores", methods=["GET"])
def get_conductores():
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT id, nombre_usuario FROM usuarios WHERE rol='conductor'")
    conductores = cursor.fetchall()
    cursor.close()
    conexion.close()
    return jsonify(conductores)


@app.route("/api/vehiculos/conductor/<username>", methods=["GET"])
def vehiculo_conductor(username):
    vehiculo = db.obtener_vehiculo_por_conductor(username)  
    if not vehiculo:
        return jsonify({"error": "No se encontró vehículo"}), 404
    return jsonify(vehiculo)

@app.route("/api/vehiculos/estado/<username>", methods=["PUT"])
def actualizar_estado_vehiculos(username):
    data = request.get_json()
    if not data or "estado" not in data:
        return jsonify({"error": "Faltan datos"}), 400

    estado = data["estado"]  

    try:
        
        filas_afectadas = db.actualizar_vehiculos_por_conductor(username, estado)
        return jsonify({
            "success": True,
            "mensaje": f"{filas_afectadas} vehículo(s) actualizados a {estado}"
        })
    except Exception as e:
        print("Error actualizando vehículos:", e)
        return jsonify({"error": "Error actualizando vehículos"}), 500


@app.route("/api/vehiculos/usuario/<usuario>", methods=["GET"])
def get_vehiculos_usuario(usuario):
    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM vehiculos WHERE conductor=%s", (usuario,))
        vehiculos = cursor.fetchall()
        return jsonify(vehiculos)
    finally:
        cursor.close()
        conexion.close()



@app.route("/api/vehiculos/<int:id>/estado", methods=["PUT"])
def update_estado_vehiculo(id):
    data = request.json
    if not data or "estado" not in data:
        return jsonify({"error": "Faltan datos"}), 400

    estado = data["estado"]

    conexion = db.get_connection()
    cursor = conexion.cursor()
    try:
        cursor.execute("UPDATE vehiculos SET estado=%s WHERE id=%s", (estado, id))
        conexion.commit()
        return jsonify({"status": "ok"})
    finally:
        cursor.close()
        conexion.close()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

