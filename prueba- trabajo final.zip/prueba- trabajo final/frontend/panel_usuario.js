let vehiculos = [];

// --- Cargar vehículos desde la base de datos ---
async function cargarVehiculos() {
  try {
    const res = await fetch("/api/vehiculos");
    vehiculos = await res.json();
    renderMapa(vehiculos);
    renderLlegadas(vehiculos);
  } catch (e) {
    console.error("Error cargando vehículos:", e);
  }
}

// Renderiza los marcadores en el mapa
function renderMapa(lista = vehiculos) {
  const contenedor = document.getElementById("marcadores");
  contenedor.innerHTML = "";

  lista.forEach(v => {
    const marcador = document.createElement("div");
    marcador.classList.add("marcador", v.tipo.toLowerCase());
    marcador.style.left = `${v.x}%`;
    marcador.style.top = `${v.y}%`;
    marcador.title = `${v.tipo} - Ruta ${v.ruta}`;
    marcador.onclick = () => mostrarDetalles(v);
    contenedor.appendChild(marcador);
  });
}

// Renderiza las próximas llegadas
function renderLlegadas(lista = vehiculos) {
  const ul = document.getElementById("lista-llegadas");
  ul.innerHTML = "";
  lista.forEach(v => {
    const li = document.createElement("li");
    const tiempo = Math.floor(Math.random() * 8) + 2; // opcional: tiempo estimado
    li.innerHTML = `<strong>${v.tipo} Ruta ${v.ruta}</strong> — ${tiempo} min`;
    ul.appendChild(li);
  });
}

// Muestra detalles en la ventana modal
function mostrarDetalles(v) {
  document.getElementById("tipo").textContent = v.tipo;
  document.getElementById("ruta").textContent = v.ruta;
  document.getElementById("estado").textContent = v.estado;
  document.getElementById("distancia").textContent = v.distancia;
  document.getElementById("detalles").classList.remove("oculto");
}

document.getElementById("cerrar-detalles").addEventListener("click", () => {
  document.getElementById("detalles").classList.add("oculto");
});

// Botón “Ver detalles” muestra ruta seleccionada
document.getElementById("btn-detalles").addEventListener("click", () => {
  const filtro = document.getElementById("filtro-ruta").value;
  
  if (!filtro) {
    alert("Selecciona una ruta para ver los detalles");
    return;
  }

  const filtrados = vehiculos.filter(v => v.ruta === filtro);

  if (filtrados.length === 0) {
    alert("No hay vehículos activos en esta ruta");
    return;
  }

  mostrarDetalles(filtrados[0]);
});

// Filtro por ruta
document.getElementById("filtro-ruta").addEventListener("change", e => {
  const valor = e.target.value;
  const filtrados = valor ? vehiculos.filter(v => v.ruta === valor) : vehiculos;
  renderMapa(filtrados);
  renderLlegadas(filtrados);
});

// Búsqueda
document.getElementById("buscar").addEventListener("input", e => {
  const texto = e.target.value.toLowerCase();
  const filtrados = vehiculos.filter(v =>
    v.ruta.toLowerCase().includes(texto) || v.tipo.toLowerCase().includes(texto)
  );
  renderMapa(filtrados);
  renderLlegadas(filtrados);
});

// Simulación de movimiento opcional
function simularMovimiento() {
  vehiculos = vehiculos.map(v => ({
    ...v,
    x: Math.min(90, Math.max(10, v.x + (Math.random() - 0.5) * 8)),
    y: Math.min(90, Math.max(10, v.y + (Math.random() - 0.5) * 8)),
    distancia: `${Math.floor(Math.random() * 500) + 100} m`
  }));

  const filtro = document.getElementById("filtro-ruta").value;
  const filtrados = filtro ? vehiculos.filter(v => v.ruta === filtro) : vehiculos;

  renderMapa(filtrados);
  renderLlegadas(filtrados);
}

document.getElementById("btn-refrescar").addEventListener("click", simularMovimiento);

// Botón inicio
document.getElementById("btn-inicio").addEventListener("click", () => {
  window.location.href = "/login";
});

// Inicialización
cargarVehiculos();
setInterval(cargarVehiculos, 8000); // refresca desde BD cada 8 segundos

async function verificarEstadoCuenta() {
  try {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) return;

    const res = await fetch(`/api/usuarios/${usuario.id}`);
    const data = await res.json();

    if (data.estado === "bloqueado") {

      const msg = document.getElementById("mensaje-bloqueo");
      msg.classList.remove("oculto");

      setTimeout(() => {
        localStorage.removeItem("usuario");
        window.location.href = "/login";
      }, 2500);
    }
  } catch (e) {
    console.error("Error verificando estado:", e);
  }
}


// Revisar cada 5 segundos
setInterval(verificarEstadoCuenta, 5000);
verificarEstadoCuenta();