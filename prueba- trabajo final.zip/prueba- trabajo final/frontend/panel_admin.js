//------------------------------------------------------
// FUNCIONES LOCALSTORAGE
//------------------------------------------------------
const usuarioActual = localStorage.getItem("usuarioLogueado") || "admin";



function guardarDatos() {
    localStorage.setItem("rutas", JSON.stringify(rutas));
    localStorage.setItem("vehiculos", JSON.stringify(vehiculos));
    localStorage.setItem("bitacora", JSON.stringify(bitacora));
}

function cargarDatos() {
    const rutasGuardadas = localStorage.getItem("rutas");
    const vehiculosGuardados = localStorage.getItem("vehiculos");
    const bitacoraGuardada = localStorage.getItem("bitacora");

    if (rutasGuardadas) rutas = JSON.parse(rutasGuardadas);
    if (vehiculosGuardados) vehiculos = JSON.parse(vehiculosGuardados);
    if (bitacoraGuardada) bitacora = JSON.parse(bitacoraGuardada);
}

//------------------------------------------------------
// MOCK DATA / VARIABLES GLOBALES
//------------------------------------------------------
let rutas = [
    { id: 1, nombre: "Centro - Norte", origen: "Centro" },
    { id: 2, nombre: "Sur - Oeste", origen: "Sur" },
    { id: 3, nombre: "Este - Centro", origen: "Este" }
];

let vehiculos = [
    { id: 1, tipo: "taxi", patente: "AA123BB", ruta: "Centro - Norte", conductor: "102" },
    { id: 2, tipo: "colectivo", patente: "AC567RT", ruta: "Sur - Oeste", conductor: "88" }
];

let bitacora = [];

cargarDatos(); // load persistent data

//------------------------------------------------------
// CAMBIO DE SECCIONES
//------------------------------------------------------
const sidebarLinks = document.querySelectorAll(".sidebar a");
const sections = document.querySelectorAll(".panel-section");

sidebarLinks.forEach(link => {
    link.addEventListener("click", () => {
        sidebarLinks.forEach(l => l.classList.remove("active"));
        link.classList.add("active");

        sections.forEach(sec => sec.classList.remove("active"));
        document.getElementById(link.dataset.section).classList.add("active");
    });
});

//------------------------------------------------------
// CARGA DE TABLAS
//------------------------------------------------------
function cargarRutas() {
    const tbody = document.querySelector("#tablaRutas tbody");
    tbody.innerHTML = "";
    rutas.forEach(r => {
        tbody.innerHTML += `
        <tr>
            <td>${r.nombre}</td>
            <td>${r.origen}</td>
            <td><button onclick="eliminarRuta(${r.id})">Eliminar</button></td>
        </tr>`;
    });
    cargarSelectRutas();
}

function cargarVehiculos() {
    const tbody = document.querySelector("#tablaVehiculos tbody");
    tbody.innerHTML = "";
    vehiculos.forEach(v => {
        tbody.innerHTML += `
        <tr>
            <td>${v.tipo}</td>
            <td>${v.patente}</td>
            <td>${v.ruta}</td>
            <td>${v.conductor}</td>
            <td><button onclick="eliminarVehiculo(${v.id})">Eliminar</button></td>
        </tr>`;
    });
}

function cargarBitacora(data = bitacora) {
    const tbody = document.querySelector("#tablaBitacora tbody");
    tbody.innerHTML = "";
    data.forEach(log => {
        tbody.innerHTML += `
        <tr>
            <td>${log.usuario}</td>
            <td>${log.fecha}</td>
            <td>${log.accion}</td>
            <td>${log.resultado}</td>
        </tr>`;
    });
}

cargarRutas();
cargarVehiculos();
cargarBitacora();

//------------------------------------------------------
// CREAR RUTA
//------------------------------------------------------
document.getElementById("btnCrearRuta").addEventListener("click", () => {
    const nombre = document.getElementById("rutaNombre").value;
    const origen = document.getElementById("rutaOrigen").value;

    if (!nombre || !origen) return alert("Completa los campos");

    rutas.push({ id: rutas.length + 1, nombre, origen });
    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Creación ruta ${nombre}`,
        resultado: "Éxito"
    });

    guardarDatos();
    cargarRutas();
    cargarBitacora();

    document.getElementById("rutaNombre").value = "";
    document.getElementById("rutaOrigen").value = "";
});

//------------------------------------------------------
// ELIMINAR RUTA
//------------------------------------------------------
function eliminarRuta(id) {
    const ruta = rutas.find(r => r.id === id);
    rutas = rutas.filter(r => r.id !== id);

    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Ruta eliminada ${ruta.nombre}`,
        resultado: "Éxito"
    });

    guardarDatos();
    cargarRutas();
    cargarBitacora();
}

//------------------------------------------------------
// SELECT DE RUTAS PARA VEHÍCULOS
//------------------------------------------------------
function cargarSelectRutas() {
    const select = document.getElementById("vehRuta");
    select.innerHTML = `<option value="">Seleccionar ruta</option>`;
    rutas.forEach(r => {
        const option = document.createElement("option");
        option.value = r.nombre;
        option.textContent = r.nombre;
        select.appendChild(option);
    });
}

//------------------------------------------------------
// CREAR VEHÍCULO
//------------------------------------------------------
document.getElementById("btnCrearVeh").addEventListener("click", () => {
    const tipo = document.getElementById("vehTipo").value;
    const patente = document.getElementById("vehPatente").value;
    const conductor = document.getElementById("vehConductor").value;
    const rutaAsignada = document.getElementById("vehRuta").value;

    if (!patente || !conductor || !rutaAsignada)
        return alert("Completa todos los campos y selecciona una ruta");

    vehiculos.push({
        id: vehiculos.length + 1,
        tipo,
        patente,
        ruta: rutaAsignada,
        conductor
    });

    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Vehículo ${patente} asignado a ${rutaAsignada}`,
        resultado: "Éxito"
    });

    guardarDatos();
    cargarVehiculos();
    cargarBitacora();

    document.getElementById("vehPatente").value = "";
    document.getElementById("vehConductor").value = "";
    document.getElementById("vehRuta").value = "";
});

//------------------------------------------------------
// ELIMINAR VEHÍCULO
//------------------------------------------------------
function eliminarVehiculo(id) {
    const veh = vehiculos.find(v => v.id === id);
    vehiculos = vehiculos.filter(v => v.id !== id);

    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Vehículo eliminado ${veh.patente}`,
        resultado: "Éxito"
    });

    guardarDatos();
    cargarVehiculos();
    cargarBitacora();
}

//------------------------------------------------------
// FILTRO DE BITÁCORA
//------------------------------------------------------
document.getElementById("btnFiltrarBitacora").addEventListener("click", () => {
    const fecha = document.getElementById("filtroFecha").value;
    const usuario = document.getElementById("filtroUsuario").value.toLowerCase();

    const filtrado = bitacora.filter(log => {
        return (
            (!fecha || log.fecha === fecha) &&
            (!usuario || log.usuario.toLowerCase().includes(usuario))
        );
    });

    cargarBitacora(filtrado);
});

//------------------------------------------------------
// ESCANEO DE INTEGRIDAD
//------------------------------------------------------
document.getElementById("btnScan").addEventListener("click", () => {
    let errores = [];

    vehiculos.forEach(v => {
        if (!v.ruta) errores.push(`Vehículo ${v.patente} no tiene ruta asignada`);
        if (!v.conductor) errores.push(`Vehículo ${v.patente} no tiene conductor`);
    });

    rutas.forEach(r => {
        const asignados = vehiculos.filter(v => v.ruta === r.nombre);
        if (asignados.length === 0)
            errores.push(`Ruta ${r.nombre} no tiene vehículos asignados`);
    });

    const box = document.getElementById("scanResultado");

    if (errores.length === 0) {
        box.textContent = "Sin problemas detectados.";
        box.style.background = "#d1fae5";
    } else {
        box.innerHTML = errores.join("<br>");
        box.style.background = "#fee2e2";
    }
});

//------------------------------------------------------
// BOTÓN DE INICIO → REDIRECCIÓN
//------------------------------------------------------
document.getElementById("btn-inicio").addEventListener("click", () => {
    window.location.href = "/";
});

//------------------------------------------------------
// CARGA TABLA SEGURIDAD (USUARIOS)
//------------------------------------------------------
async function cargarSeguridad() {
    const res = await fetch("/api/usuarios"); // solo tabla users
    const users = await res.json();
    const tbody = document.querySelector("#tablaSeguridad tbody");

    tbody.innerHTML = "";
    users.forEach(u => {
        tbody.innerHTML += `<tr>
        <td>${u.username}</td>
        <td>${u.estado}</td>
        <td>
            <button onclick="toggleEstado(${u.id}, '${u.estado}', '${u.username}')">
                ${u.estado === "activo" ? "Bloquear" : "Desbloquear"}
            </button>
            <button onclick="eliminarUsuario(${u.id})">Eliminar</button>
        </td>
    </tr>`;
    });
}

//------------------------------------------------------
// FUNCIONES BLOQUEAR Y ELIMINAR USUARIO
//------------------------------------------------------
async function toggleEstado(id, estadoActual, username) {  // agregamos username
    const nuevoEstado = estadoActual === "activo" ? "bloqueado" : "activo";

    try {
        const res = await fetch(`/api/usuarios/${id}/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({ error: 'error' }));
            alert("Error actualizando estado: " + (err.error || res.status));
            return;
        }

        // Registrar en bitácora usando el nombre del usuario
        bitacora.push({
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: `Usuario ${username} ${nuevoEstado === "activo" ? "desbloqueado" : "bloqueado"}`,
            resultado: "Éxito"
        });
        guardarDatos();
        cargarBitacora();

        // refrescar tabla
        cargarSeguridad();
    } catch (e) {
        console.error("fetch error", e);
        alert("Error de conexión al actualizar estado");
    }
}


async function eliminarUsuario(id) {
    await fetch(`/api/usuarios/${id}`, { method: "DELETE" });

    // Registrar en bitácora
    bitacora.push({
        usuario: usuarioActual,
        fecha: new Date().toISOString().split("T")[0],
        accion: `Usuario eliminado ${id}`,
        resultado: "Éxito"
    });
    guardarDatos();
    cargarBitacora();
    cargarSeguridad();
}


document.getElementById("btnResetBitacora").addEventListener("click", () => {
    if (confirm("¿Querés borrar toda la bitácora? Esta acción no se puede deshacer.")) {
        // Guardar la acción de borrado en una variable temporal
        const logBorrado = {
            usuario: usuarioActual,
            fecha: new Date().toISOString().split("T")[0],
            accion: "Borrado completo de la bitácora",
            resultado: "Éxito"
        };

        // Vaciar la bitácora
        bitacora = [];

        // Agregar el log de borrado
        bitacora.push(logBorrado);

        // Guardar en localStorage
        guardarDatos();

        // Refrescar la tabla
        cargarBitacora();

        alert("Bitácora borrada y registro de admin agregado correctamente.");
    }
});


//------------------------------------------------------
// INICIALIZACIÓN SECCIÓN SEGURIDAD
//------------------------------------------------------
cargarSeguridad();
