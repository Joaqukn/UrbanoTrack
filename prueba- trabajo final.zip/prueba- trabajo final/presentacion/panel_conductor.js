let intervaloMovimiento = null;
let inicioRecorrido = null;
let distanciaRecorrida = 0;

let tipoVehiculo = null;
let habilitado = false; 

let vehiculo = {
    x: randomPos(),
    y: randomPos(),
    activo: false
};

let otrosVehiculos = [
    { x: randomPos(), y: randomPos(), color: "azul" },
    { x: randomPos(), y: randomPos(), color: "amarillo" }
];

const marcador = document.getElementById("marcadorVehiculo");
const contenedorSimulados = document.getElementById("otrosVehiculos");


function randomPos() { return Math.random() * 80 + 10; }

function actualizarMarcador() {
    marcador.style.display = "block";
    marcador.style.left = vehiculo.x + "%";
    marcador.style.top = vehiculo.y + "%";
}

function moverVehiculo() {
    let oldX = vehiculo.x;
    let oldY = vehiculo.y;

    vehiculo.x += (Math.random() - 0.5) * 5;
    vehiculo.y += (Math.random() - 0.5) * 5;

    distanciaRecorrida += Math.sqrt(Math.pow(vehiculo.x - oldX, 2) + Math.pow(vehiculo.y - oldY, 2));

    vehiculo.x = Math.max(10, Math.min(90, vehiculo.x));
    vehiculo.y = Math.max(10, Math.min(90, vehiculo.y));

    actualizarMarcador();
}

function moverVehiculosSimulados() {
    contenedorSimulados.innerHTML = "";
    otrosVehiculos.forEach(v => {
        v.x += (Math.random() - 0.5) * 4;
        v.y += (Math.random() - 0.5) * 4;

        v.x = Math.max(10, Math.min(90, v.x));
        v.y = Math.max(10, Math.min(90, v.y));

        const div = document.createElement("div");
        div.classList.add("marker", v.color);
        div.style.left = v.x + "%";
        div.style.top = v.y + "%";
        contenedorSimulados.appendChild(div);
    });
}


function bloquearRecorrido() {
    document.getElementById("btnIniciar").classList.add("disabled");
    document.getElementById("btnTerminar").classList.add("disabled");

    document.getElementById("btnIniciar").disabled = true;
    document.getElementById("btnTerminar").disabled = true;
}

function habilitarRecorrido() {
    document.getElementById("btnIniciar").classList.remove("disabled");
    document.getElementById("btnTerminar").classList.remove("disabled");

    document.getElementById("btnIniciar").disabled = false;
    document.getElementById("btnTerminar").disabled = false;
}


document.getElementById("btnServicio").addEventListener("click", () => {
    habilitado = true;
    document.getElementById("estadoVehiculo").textContent = "En servicio";
    habilitarRecorrido();
});

document.getElementById("btnFuera").addEventListener("click", () => {
    habilitado = false;
    document.getElementById("estadoVehiculo").textContent = "Fuera de servicio";
    bloquearRecorrido();
});


document.getElementById("btnIniciar").addEventListener("click", () => {
    if (!habilitado) return alert("El vehículo debe estar EN SERVICIO para iniciar.");

    document.getElementById("modalVehiculo").style.display = "flex";
});


document.querySelectorAll(".seleccion").forEach(btn => {
    btn.addEventListener("click", e => {

        tipoVehiculo = e.target.dataset.tipo;
        marcador.className = "marker " + (tipoVehiculo === "taxi" ? "amarillo" : "azul");

        document.getElementById("modalVehiculo").style.display = "none";

        vehiculo.activo = true;
        distanciaRecorrida = 0;
        inicioRecorrido = new Date();

        actualizarMarcador();

        intervaloMovimiento = setInterval(() => {
            moverVehiculo();
            moverVehiculosSimulados();
        }, 1500);
    });
});


document.getElementById("btnTerminar").addEventListener("click", () => {
    if (!vehiculo.activo) return;

    vehiculo.activo = false;
    clearInterval(intervaloMovimiento);
    marcador.style.display = "none";

    let fin = new Date();
    let duracion = Math.round((fin - inicioRecorrido) / 60000);

    const resumen = document.getElementById("resumenRecorrido");
    resumen.style.display = "block";

    resumen.innerHTML = `
        <h3>Resumen del viaje</h3>
        <p><strong>Vehículo:</strong> ${tipoVehiculo === "taxi" ? "Taxi " : "Colectivo "}</p>
        <p><strong>Inicio:</strong> ${inicioRecorrido.toLocaleTimeString()}</p>
        <p><strong>Fin:</strong> ${fin.toLocaleTimeString()}</p>
        <p><strong>Duración:</strong> ${duracion} min</p>
        <p><strong>Distancia recorrida:</strong> ${distanciaRecorrida.toFixed(2)} unidades</p>
    `;
});

