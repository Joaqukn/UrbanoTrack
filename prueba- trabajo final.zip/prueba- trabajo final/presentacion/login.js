document.getElementById("btn-login").addEventListener("click", async () => {
  const correo = document.getElementById("correo").value;
  const contrasena = document.getElementById("contrasena").value;
  const mensaje = document.getElementById("mensaje");

  if (!correo || !contrasena) {
    mensaje.textContent = "Completa todos los campos.";
    mensaje.style.color = "orange";
    return;
  }

  const res = await fetch("http://127.0.0.1:5000/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ correo, contrasena })
  });

  const data = await res.json();

  if (res.ok) {
    mensaje.textContent = "Bienvenido " + data.usuario.nombre_usuario;
    mensaje.style.color = "green";

    localStorage.setItem("usuario", JSON.stringify(data.usuario));

    if (data.usuario.rol === "administrador") {
      window.location.href = "panel_admin.html";
    } else if (data.usuario.rol === "conductor") {
      window.location.href = "panel_conductor.html";
    } else {
      window.location.href = "panel_usuario.html";
    }
  } else {
    mensaje.textContent = data.error;
    mensaje.style.color = "red";
  }
});
