from flask import Flask, request, jsonify
from flask_cors import CORS
import bcrypt
import db

app = Flask(__name__)
CORS(app)




@app.route("/register", methods=["POST"])
def register():
    data = request.json
    nombre_usuario = data.get("nombre_usuario")
    correo = data.get("correo")
    contrasena = data.get("contrasena")
    rol = data.get("rol", "pasajero")

    hashed = bcrypt.hashpw(contrasena.encode('utf-8'), bcrypt.gensalt())

    conexion = db.get_connection()
    cursor = conexion.cursor()

    try:
        cursor.execute(
            "INSERT INTO usuarios (nombre_usuario, correo, contrasena, rol) VALUES (%s, %s, %s, %s)",
            (nombre_usuario, correo, hashed, rol)
        )
        conexion.commit()
        return jsonify({"mensaje": "Usuario registrado correctamente"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    finally:
        cursor.close()
        conexion.close()



@app.route("/login", methods=["POST"])
def login():
    data = request.json
    correo = data.get("correo")
    contrasena = data.get("contrasena")

    conexion = db.get_connection()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM usuarios WHERE correo = %s", (correo,))
    usuario = cursor.fetchone()

    cursor.close()
    conexion.close()

    if usuario and bcrypt.checkpw(contrasena.encode('utf-8'), usuario["contrasena"].encode('utf-8')):
        return jsonify({
            "mensaje": "Login exitoso",
            "usuario": {
                "id": usuario["id"],
                "nombre_usuario": usuario["nombre_usuario"],
                "rol": usuario["rol"]
            }
        })
    else:
        return jsonify({"error": "Correo o contraseña incorrectos"}), 401
    



if __name__ == "__main__":
    app.run(debug=True)
